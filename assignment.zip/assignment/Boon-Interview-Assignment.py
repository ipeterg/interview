import sqlite3
import openapi_client

from generated_client.openapi_client.access_requests_api import AccessRequestsApi

# Load the API configuration
with open('openapitools.json') as f:
    config = json.load(f)

# Authentication token
TOKEN = 'xyz'

# API endpoint
API_URL = config['servers'][0]['url'] + '/groups'

# Create an instance of the API client with the base URL and authentication headers
api_client = ApiClient(base_url=config['servers'][0]['url'], header_name='Authorization', header_value=f'Bearer {TOKEN}')

# Create an instance of the GroupsApi using the API client
groups_api = GroupsApi(api_client)

try:
    # Retrieve groups from the API
    groups = groups_api.get_groups()
    
    # Connect to SQLite database
    conn = sqlite3.connect('api_endpoints.db')
    cursor = conn.cursor()
    
    # Create table to store groups
    cursor.execute('''CREATE TABLE IF NOT EXISTS groups
                      (id INTEGER PRIMARY KEY, name TEXT, description TEXT)''')
    
    # Insert group information into database
    for group in groups:
        name = group.name
        description = group.description
        cursor.execute('''INSERT INTO groups (name, description)
                          VALUES (?, ?)''', (name, description))
    
    # Commit changes and close connection
    conn.commit()
    conn.close()
    
    print("Groups successfully stored in database.")
except Exception as e:
    print(f"Failed to retrieve groups from API: {e}")
